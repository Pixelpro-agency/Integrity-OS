#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${1:-$(pwd)}"
FILES_ROOT="$PACKAGE_ROOT/repository-files"

cd "$REPO_ROOT"

if [[ ! -f "docs/00-current/Project_Integrity_OS_TODO_MVP_v0_8.md" ]]; then
  echo "ERRORE: il percorso non sembra il root della repository Integrity-OS." >&2
  exit 1
fi

mkdir -p \
  docs/10-executions/TODO-0101/analysis/decisions/history \
  docs/10-executions/TODO-0101/analysis/verification/history \
  docs/10-executions/TODO-0101/analysis/decision-log/history \
  docs/10-executions/TODO-0101/analysis/checkpoints/history \
  docs/10-executions/TODO-0101/instructions/superseded/history

move_if_present() {
  local src="$1"
  local dst="$2"

  if [[ -f "$src" ]]; then
    mkdir -p "$(dirname "$dst")"
    if [[ -e "$dst" ]]; then
      echo "SKIP MOVE: destinazione già presente: $dst"
    else
      mv "$src" "$dst"
      echo "MOVED: $src -> $dst"
    fi
  fi
}

while IFS=$'\t' read -r src dst; do
  [[ "$src" == "source" ]] && continue
  move_if_present "$src" "$dst"
done < "$PACKAGE_ROOT/MOVE_MANIFEST.tsv"

cp -a "$FILES_ROOT/." "$REPO_ROOT/"

required=(
  "docs/10-executions/TODO-0101/README.md"
  "docs/10-executions/TODO-0101/analysis/verification/Project_Integrity_OS_Correction_Set_TODO-0101_v0_2_DRAFT.md"
  "docs/10-executions/TODO-0101/analysis/decision-log/Project_Integrity_OS_Decision_Log_TODO-0101_v0_7_DRAFT.md"
  "docs/10-executions/TODO-0101/analysis/checkpoints/Project_Integrity_OS_Checkpoint_Index_TODO-0101_v0_7_DRAFT.md"
  "docs/10-executions/TODO-0101/analysis/decisions/Project_Integrity_OS_15_Schema_Completo_Implementazione_Progressiva_TODO-0101_v0_3_DRAFT.md"
)

for file in "${required[@]}"; do
  if [[ ! -f "$file" ]]; then
    echo "ERRORE: file richiesto assente dopo la copia: $file" >&2
    exit 1
  fi
done

git diff --check

echo
echo "=== GIT STATUS ==="
git status --short
echo
echo "Applicazione documentale completata."
echo "Nessun commit e nessun push sono stati eseguiti."
