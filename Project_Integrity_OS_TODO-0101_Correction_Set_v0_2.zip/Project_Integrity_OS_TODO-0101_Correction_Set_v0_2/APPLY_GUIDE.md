# Project Integrity OS — TODO-0101

## Guida di applicazione — Correction Set v0.2

Questo pacchetto contiene file completi, non patch.

Non modifica:

```text
src/
src-tauri/
package.json
package-lock.json
Cargo.toml
Cargo.lock
```

---

# 1. Contenuto

```text
repository-files/
apply_todo_0101_correction_set_v0_2.sh
MOVE_MANIFEST.tsv
MANIFEST_SHA256.txt
```

`repository-files/` riproduce i percorsi finali della repository.

---

# 2. Applicazione automatica

Da Git Bash:

```bash
cd "/percorso/del/pacchetto"
bash apply_todo_0101_correction_set_v0_2.sh "/percorso/Integrity-OS"
```

Lo script:

1. verifica il root della repository;
2. crea le directory history;
3. sposta le versioni sostituite;
4. conserva il brief originario sotto `instructions/superseded/history/`;
5. copia i nuovi file completi;
6. controlla che i file previsti esistano;
7. esegue `git diff --check`;
8. mostra `git status --short`.

Lo script non crea commit e non esegue push.

---

# 3. Controllo manuale

Dopo l'applicazione:

```bash
cd "/percorso/Integrity-OS"

git status --short
git diff --check
git diff -- docs/10-executions/TODO-0101
```

Verificare che nelle directory correnti restino soltanto:

```text
Decision Log v0.7
Checkpoint Index v0.7
Correction Set v0.2
decision documents indicati dal README
```

---

# 4. Stato previsto

```text
DECISIONAL CONSOLIDATION: COMPLETE
SCHEMA ARCHITECTURE: NOT PRODUCED
FINAL BRIEF: NOT PRODUCED
IMPLEMENTATION: BLOCKED
```

Il pacchetto non porta TODO-0101 a READY.
