# Istruzioni di applicazione

## 1. Estrazione

Estrarre la directory:

```text
Project_Integrity_OS_TODO-0101_Correction_Set_v0_1
```

in una posizione qualsiasi.

## 2. Repository

Aprire Git Bash nella root locale:

```bash
cd "/c/Users/Utente/Desktop/Project Integrity OS"
```

Verificare:

```bash
git branch --show-current
git status --short --branch
```

Il branch deve essere:

```text
review/todo-0101-schema-20260806-023458
```

Il working tree deve essere pulito.

## 3. Applicazione

Eseguire lo script indicando il percorso nel quale è stato estratto il pacchetto:

```bash
bash "/c/PERCORSO/Project_Integrity_OS_TODO-0101_Correction_Set_v0_1/apply_todo_0101_corrections.sh"
```

Lo script:

- archivia le cinque versioni decisionali v0.1 sostituite;
- archivia Decision Log v0.5;
- archivia Checkpoint Index v0.5;
- installa le versioni corrette v0.2;
- crea Decision Log v0.6;
- crea Checkpoint Index v0.6;
- crea README operativo;
- crea il Correction Set;
- verifica i percorsi;
- verifica le cinque correzioni;
- esegue `git diff --check`;
- non esegue commit;
- non esegue push.

## 4. Controllo manuale

```bash
git status --short
git diff --summary
git diff --check
```

## 5. Commit

Dopo la verifica:

```bash
git add -A
git diff --cached --check
git commit -m "docs(todo-0101): consolidate relational corrections"
git push origin review/todo-0101-schema-20260806-023458
```
