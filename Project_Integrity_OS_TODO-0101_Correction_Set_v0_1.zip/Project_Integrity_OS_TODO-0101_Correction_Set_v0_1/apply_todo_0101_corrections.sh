#!/usr/bin/env bash
set -euo pipefail

EXPECTED_BRANCH="review/todo-0101-schema-20260806-023458"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "$REPO_ROOT" ]; then
    echo "ERRORE: eseguire lo script all'interno della repository Git."
    exit 1
fi

CURRENT_BRANCH="$(git -C "$REPO_ROOT" branch --show-current)"
if [ "$CURRENT_BRANCH" != "$EXPECTED_BRANCH" ]; then
    echo "ERRORE: branch corrente inatteso."
    echo "Atteso:   $EXPECTED_BRANCH"
    echo "Corrente: $CURRENT_BRANCH"
    exit 1
fi

if [ -n "$(git -C "$REPO_ROOT" status --porcelain)" ]; then
    echo "ERRORE: working tree non pulito."
    git -C "$REPO_ROOT" status --short
    exit 1
fi

BASE="$REPO_ROOT/docs/10-executions/TODO-0101"
ANALYSIS="$BASE/analysis"
DECISIONS="$ANALYSIS/decisions"
DECISION_HISTORY="$DECISIONS/history"
DECISION_LOG="$ANALYSIS/decision-log"
DECISION_LOG_HISTORY="$DECISION_LOG/history"
CHECKPOINTS="$ANALYSIS/checkpoints"
CHECKPOINT_HISTORY="$CHECKPOINTS/history"

mkdir -p \
    "$DECISION_HISTORY" \
    "$DECISION_LOG_HISTORY" \
    "$CHECKPOINT_HISTORY" \
    "$ANALYSIS/verification"

move_to_history() {
    local source="$1"
    local target="$2"

    if [ ! -f "$source" ]; then
        echo "ERRORE: sorgente mancante: $source"
        exit 1
    fi

    if [ -e "$target" ]; then
        echo "ERRORE: destinazione già esistente: $target"
        exit 1
    fi

    git -C "$REPO_ROOT" mv "$source" "$target"
}

move_to_history \
    "$DECISIONS/Project_Integrity_OS_08_Registro_Elementi_Irrisolti_TODO-0101_v0_1_DRAFT.md" \
    "$DECISION_HISTORY/Project_Integrity_OS_08_Registro_Elementi_Irrisolti_TODO-0101_v0_1_DRAFT.md"

move_to_history \
    "$DECISIONS/Project_Integrity_OS_10_Integrita_Trasversale_Anti_Orfano_TODO-0101_v0_1_DRAFT.md" \
    "$DECISION_HISTORY/Project_Integrity_OS_10_Integrita_Trasversale_Anti_Orfano_TODO-0101_v0_1_DRAFT.md"

move_to_history \
    "$DECISIONS/Project_Integrity_OS_12_Ruoli_Permessi_Sensibilita_Redazione_TODO-0101_v0_1_DRAFT.md" \
    "$DECISION_HISTORY/Project_Integrity_OS_12_Ruoli_Permessi_Sensibilita_Redazione_TODO-0101_v0_1_DRAFT.md"

move_to_history \
    "$DECISIONS/Project_Integrity_OS_14_Cardinalita_Tabelle_Associative_TODO-0101_v0_1_DRAFT.md" \
    "$DECISION_HISTORY/Project_Integrity_OS_14_Cardinalita_Tabelle_Associative_TODO-0101_v0_1_DRAFT.md"

move_to_history \
    "$DECISIONS/Project_Integrity_OS_15_Schema_Completo_Implementazione_Progressiva_TODO-0101_v0_1_DRAFT.md" \
    "$DECISION_HISTORY/Project_Integrity_OS_15_Schema_Completo_Implementazione_Progressiva_TODO-0101_v0_1_DRAFT.md"

move_to_history \
    "$DECISION_LOG/Project_Integrity_OS_Decision_Log_TODO-0101_v0_5_DRAFT.md" \
    "$DECISION_LOG_HISTORY/Project_Integrity_OS_Decision_Log_TODO-0101_v0_5_DRAFT.md"

move_to_history \
    "$CHECKPOINTS/Project_Integrity_OS_Checkpoint_Index_TODO-0101_v0_5_DRAFT.md" \
    "$CHECKPOINT_HISTORY/Project_Integrity_OS_Checkpoint_Index_TODO-0101_v0_5_DRAFT.md"

cp -a "$PAYLOAD/." "$REPO_ROOT/"

echo "=== VERIFICA FILE CORRENTI ==="

required_files=(
    "$BASE/README.md"
    "$DECISIONS/Project_Integrity_OS_08_Registro_Elementi_Irrisolti_TODO-0101_v0_2_DRAFT.md"
    "$DECISIONS/Project_Integrity_OS_10_Integrita_Trasversale_Anti_Orfano_TODO-0101_v0_2_DRAFT.md"
    "$DECISIONS/Project_Integrity_OS_12_Ruoli_Permessi_Sensibilita_Redazione_TODO-0101_v0_2_DRAFT.md"
    "$DECISIONS/Project_Integrity_OS_14_Cardinalita_Tabelle_Associative_TODO-0101_v0_2_DRAFT.md"
    "$DECISIONS/Project_Integrity_OS_15_Schema_Completo_Implementazione_Progressiva_TODO-0101_v0_2_DRAFT.md"
    "$DECISION_LOG/Project_Integrity_OS_Decision_Log_TODO-0101_v0_6_DRAFT.md"
    "$CHECKPOINTS/Project_Integrity_OS_Checkpoint_Index_TODO-0101_v0_6_DRAFT.md"
    "$ANALYSIS/verification/Project_Integrity_OS_Correction_Set_TODO-0101_v0_1_DRAFT.md"
)

for file in "${required_files[@]}"; do
    test -f "$file" || {
        echo "ERRORE: file richiesto mancante: $file"
        exit 1
    }
    echo "OK: ${file#"$REPO_ROOT/"}"
done

echo
echo "=== CONTROLLO PERCORSI OBSOLETI NEI FILE CORRENTI ==="
if grep -RIn \
    --include='*.md' \
    -E 'docs/00-current/Project_Integrity_OS_(Principi|Modello|Context|Provenienza|Sintesi|Requisiti|Lifecycle|Registro|Eventi|Integrita|Conservazione|Ruoli|Transizioni|Cardinalita|Schema)|analysis/history/Project_Integrity_OS_Decision_Log_Pre|history/checkpoints/CHECKPOINT_INDEX' \
    "$BASE/README.md" \
    "$DECISION_LOG/Project_Integrity_OS_Decision_Log_TODO-0101_v0_6_DRAFT.md" \
    "$CHECKPOINTS/Project_Integrity_OS_Checkpoint_Index_TODO-0101_v0_6_DRAFT.md"; then
    echo "ERRORE: percorso obsoleto trovato."
    exit 1
fi

echo "OK: nessun percorso obsoleto nei documenti correnti."

echo
echo "=== CONTROLLO CORREZIONI ==="
grep -q 'BUG' "$DECISIONS/Project_Integrity_OS_08_Registro_Elementi_Irrisolti_TODO-0101_v0_2_DRAFT.md"
grep -q 'projects.project_id = project_entities.entity_id' "$DECISIONS/Project_Integrity_OS_10_Integrita_Trasversale_Anti_Orfano_TODO-0101_v0_2_DRAFT.md"
grep -q 'project_memberships' "$DECISIONS/Project_Integrity_OS_12_Ruoli_Permessi_Sensibilita_Redazione_TODO-0101_v0_2_DRAFT.md"
grep -q 'REPORT 1 ── 1 REPORT_OWNERSHIP' "$DECISIONS/Project_Integrity_OS_14_Cardinalita_Tabelle_Associative_TODO-0101_v0_2_DRAFT.md"
grep -q 'CARDINALITÀ STRUTTURALE' "$DECISIONS/Project_Integrity_OS_14_Cardinalita_Tabelle_Associative_TODO-0101_v0_2_DRAFT.md"
grep -q 'SYSTEM_CATALOG' "$DECISIONS/Project_Integrity_OS_15_Schema_Completo_Implementazione_Progressiva_TODO-0101_v0_2_DRAFT.md"

echo "OK: cinque correzioni presenti."

echo
echo "=== CONTROLLO PATCH ==="
git -C "$REPO_ROOT" diff --check

echo
echo "=== STATO GIT ==="
git -C "$REPO_ROOT" status --short

echo
echo "Correction set applicato. Nessun commit o push è stato eseguito."
